from django.apps import AppConfig


class MimeappConfig(AppConfig):
    name = 'mimeapp'
