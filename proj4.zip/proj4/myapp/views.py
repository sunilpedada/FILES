from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import View
class home(View):
    def get(self,request):
        return render(request,"home.html")
class register(View):
    def get(self,request):
        return render(request,"register.html")
    def post(self,request):
        a = request.POST["userid"]
        b = request.POST["passid"]
        c = request.POST["username"]
        d = request.POST["address"]
        e = request.POST["country"]
        f = request.POST["zip"]
        g = request.POST["email"]
        h = request.POST["sex"]
        i = request.POST["en"]
        j = request.POST["nonen"]
        k = request.POST["desc"]
        print(a, b, c, d, e, f, g, h, i, j, k)
        return HttpResponse("registration success")
class login(View):
    def get(self,request):
        return render(request,"login.html")
    def post(self,request):
        a = request.POST["un"]
        b = request.POST["pwd"]
        print(a, b)
        return HttpResponse("login success")
