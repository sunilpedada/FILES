from django.apps import AppConfig


class Myapp1Config(AppConfig):
    name = 'myapp1'
