from django.conf.urls import url
from.import views
app_name="mimeapp"
urlpatterns=[url(r'^csv$',views.csvview,name="csvview"),
             url(r'^pdf$',views.pdfview,name="pdfview"),
             url(r'^html$',views.htmlview,name="htmlview"),
             url(r'^xml$',views.xmlview,name="xmlview"),
             ]